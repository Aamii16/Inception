#!/bin/bash

service mariadb start

#uncomment this when you finish whole rpoject setup and compose

#DB_NAME="$MYSQL_DATABASE"
#DB_USER="$MYSQL_USER"
#DB_PASSWORD="$(cat /run/secrets/db_password)"
#DB_ROOT_PASSWORD="$(cat /run/secrets/db_root_password)"


DB_NAME="wordpressdb"
DB_USER="wp_user"
DB_PASSWORD="wp_pwd"
DB_ROOT_PASSWORD="root_pwd"

mysql -e "CREATE DATABASE IF NOT EXISTS \`$DB_NAME\`;"

mysql -e "CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';"

mysql -e "GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'%';"

mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$DB_ROOT_PASSWORD';"

mysql -e "FLUSH PRIVILEGES;"

mysqladmin -u root -p$DB_ROOT_PASSWORD shutdown

mysqld